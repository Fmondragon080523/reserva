<?php
$conexion = new mysqli("localhost", "root", "", "club_padel");
$conexion->set_charset("utf8");

$resultado = $conexion->query("SELECT dia, hora, cancha, cliente FROM reservas");
$reservas = [];

while ($fila = $resultado->fetch_assoc()) {
    $reservas[] = $fila;
}

echo json_encode($reservas);
?>