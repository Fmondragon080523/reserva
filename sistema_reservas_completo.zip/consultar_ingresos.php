<?php
$conexion = new mysqli("localhost", "root", "", "club_padel");
$conexion->set_charset("utf8");

$resultado = $conexion->query("SELECT efectivo, tarjeta FROM ingresos");
$ingresos = [];

while ($fila = $resultado->fetch_assoc()) {
    $ingresos[] = $fila;
}

echo json_encode($ingresos);
?>