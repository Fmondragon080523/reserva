<?php
$conexion = new mysqli("localhost", "root", "", "club_padel");
if ($conexion->connect_error) { die("Error de conexión: " . $conexion->connect_error); }
$conexion->set_charset("utf8");

$dia = $_POST['dia'];
$hora = $_POST['hora'];
$cancha = $_POST['cancha'];
$cliente = $_POST['cliente'];

$stmt = $conexion->prepare("INSERT INTO reservas (dia, hora, cancha, cliente) VALUES (?, ?, ?, ?)");
$stmt->bind_param("ssss", $dia, $hora, $cancha, $cliente);

echo $stmt->execute() ? "Reserva guardada exitosamente." : "Error al guardar reserva.";

$stmt->close(); $conexion->close();
?>