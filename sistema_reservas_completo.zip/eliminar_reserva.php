<?php
$conexion = new mysqli("localhost", "root", "", "club_padel");
$conexion->set_charset("utf8");

$dia = $_POST['dia'];
$hora = $_POST['hora'];
$cancha = $_POST['cancha'];
$cliente = $_POST['cliente'];

$stmt = $conexion->prepare("DELETE FROM reservas WHERE dia=? AND hora=? AND cancha=? AND cliente=?");
$stmt->bind_param("ssss", $dia, $hora, $cancha, $cliente);

echo $stmt->execute() ? "Reserva eliminada exitosamente." : "Error al eliminar reserva.";

$stmt->close(); $conexion->close();
?>